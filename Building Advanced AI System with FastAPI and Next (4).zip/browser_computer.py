"""Safe browser/computer-use extension contracts for JARVIS.

This v0.1 module provides a real permissioned interface and dry-run adapter.
It does not receive arbitrary desktop access or bypass authentication/CAPTCHAs.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
from uuid import uuid4

class ComputerRisk(str, Enum):
    read_only = "read_only"
    normal = "normal"
    external_action = "external_action"
    high_impact = "high_impact"

@dataclass
class BrowserPolicy:
    allowed_domains: list[str] = field(default_factory=list)
    allow_downloads: bool = False
    allow_external_actions: bool = False
    require_approval_above: ComputerRisk = ComputerRisk.external_action

@dataclass
class BrowserSession:
    id: str
    status: str
    url: str | None = None
    events: list[dict[str, Any]] = field(default_factory=list)

class BrowserComputerAdapter:
    def __init__(self, policy: BrowserPolicy | None = None) -> None:
        self.policy = policy or BrowserPolicy()
        self.sessions: dict[str, BrowserSession] = {}

    def start_session(self, purpose: str) -> BrowserSession:
        session = BrowserSession(str(uuid4()), "ready")
        session.events.append({"type": "session.started", "purpose": purpose})
        self.sessions[session.id] = session
        return session

    def inspect(self, session_id: str, url: str) -> dict[str, Any]:
        session = self.sessions[session_id]
        session.url = url
        session.events.append({"type": "page.inspect", "url": url})
        return {"session_id": session_id, "url": url, "mode": "dry_run", "message": "Browser adapter ready for an approved browser connector."}

    def plan_action(self, session_id: str, action: str, risk: ComputerRisk) -> dict[str, Any]:
        requires_approval = risk in {ComputerRisk.external_action, ComputerRisk.high_impact}
        if requires_approval and not self.policy.allow_external_actions:
            return {"session_id": session_id, "action": action, "status": "awaiting_approval", "risk": risk.value}
        return {"session_id": session_id, "action": action, "status": "planned", "risk": risk.value}

    def stop_session(self, session_id: str) -> BrowserSession:
        session = self.sessions[session_id]
        session.status = "stopped"
        session.events.append({"type": "session.stopped"})
        return session

browser_adapter = BrowserComputerAdapter()
