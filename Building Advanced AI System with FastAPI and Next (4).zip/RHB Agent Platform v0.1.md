# RHB Agent Platform v0.1

A production-oriented foundation for **agent → plan → tool → observe → verify → remember → improve**.

## Included

- FastAPI API with API-key authentication
- PostgreSQL and Redis service definitions
- Next.js operator console
- LLM provider abstraction with deterministic mock provider
- Agent orchestration loop with planning, tool execution, observation, verification, and memory writes
- Tool registry with web research and file/document tools
- Persistent conversation/task memory model
- Background-job contract and worker service entrypoint
- Skill registry, human approval gates, audit events, and automated tests
- Extension seams for voice, browser/computer use, autonomous learning, and additional agents
- Continuous-learning controller for approved knowledge cycles and evidence-backed improvement
- Compound-brain coordinator combining planner, research, analyst, and safety-verifier lanes in parallel
- Governed skill acquisition: propose → test → evaluate → approve → activate → rollback
- Permissioned browser/computer sessions with dry-run behavior for external actions
- Browser voice activation through Web Speech APIs, with server STT/TTS provider seams
- Installable **RHB AI** PWA identity with branded icon and manifest

## Run locally

```bash
cp .env.example .env
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn app.main:app --app-dir backend --reload
```

In a second shell:

```bash
cd frontend
npm install
npm run dev
```

Or use Docker Compose when Docker is available:

```bash
docker compose up --build
```

API: http://localhost:8000/docs  |  Console: http://localhost:3000

After starting the frontend, open `http://localhost:3000` in a Chromium-based browser and choose **Install RHB AI** from the browser address-bar menu. It will open as a standalone app using the RHB AI icon. Voice activation is available where the browser supports Web Speech recognition.

The default development API key is `dev-rhb-key` and is intentionally only suitable for local development.
