# RHB AI operations guide

## 1. The important capability boundary

RHB AI is designed as an autonomous work system, not as an unlimited or infallible intelligence. A single command can create and execute a task through planning, tool use, observation, verification, memory, and result synthesis. It cannot honestly guarantee an instant correct answer for every problem, and it must pause for approval before sensitive external actions. This design removes operational pressure by making work visible, resumable, auditable, and interruptible rather than by pretending uncertainty does not exist.

## 2. Configure a custom LLM provider

The provider boundary is `backend/app/services/llm.py`. The current `MockLLMProvider` is deterministic so the repository can be tested without external credentials. Replace it with a provider adapter that implements the two methods on `LLMProvider`: `make_plan(objective, available_tools)` and `synthesize(objective, observations)`.

A minimal provider should validate structured output, keep secrets server-side, apply timeouts and retries, and return only action-level reasoning. It should not expose hidden chain-of-thought in the UI. A practical implementation pattern is:

```python
class CustomProvider(LLMProvider):
    def __init__(self, client, model: str):
        self.client, self.model = client, model

    async def make_plan(self, objective: str, available_tools: list[str]) -> Plan:
        # Ask the provider for JSON matching the Plan schema.
        # Validate every tool name against available_tools before execution.
        ...

    async def synthesize(self, objective: str, observations: list[str]) -> str:
        # Pass bounded, verified observations and request a concise result.
        ...
```

Then update `get_provider()` to select the adapter from `settings.llm_provider`, for example `mock`, `openai-compatible`, or `local`. Add provider-specific variables to `.env` without committing secrets:

```dotenv
LLM_PROVIDER=openai-compatible
LLM_API_BASE=https://your-provider.example/v1
LLM_API_KEY=replace-me
LLM_MODEL=your-model-name
LLM_TIMEOUT_SECONDS=60
```

The production checklist is: use a server-side secret store, set connection and model timeouts, validate JSON against Pydantic schemas, enforce maximum objective/observation sizes, rate-limit requests, log provider latency and request IDs, redact prompts that contain secrets, and provide a fallback or explicit failed state when the provider is unavailable.

## 3. Configure backend STT/TTS

The boundary is `backend/app/services/voice.py`. Implement `SpeechProvider.transcribe(audio, config)` and `SpeechProvider.synthesize(text, config)`. Keep the provider behind the backend so API keys and audio-processing credentials never reach the browser. A provider adapter should validate MIME type and duration, cap file size, normalize language codes, enforce request timeouts, and avoid storing raw audio unless retention is explicitly enabled.

Example configuration:

```dotenv
VOICE_PROVIDER=custom
STT_API_BASE=https://speech-provider.example
STT_API_KEY=replace-me
TTS_API_BASE=https://speech-provider.example
TTS_API_KEY=replace-me
VOICE_LANGUAGE=en-US
VOICE_WAKE_WORD=RHB
VOICE_MAX_AUDIO_SECONDS=120
```

The browser UI already has a low-friction development path using Web Speech recognition. For backend speech, add a multipart audio endpoint that calls `voice_gateway.transcribe()`, creates or updates a conversation, and sends the transcript into the normal task/chat path. For spoken responses, call `voice_gateway.synthesize()` only after the text result is finalized and policy-filtered. External actions initiated by voice must use the same approval policy as typed commands.

## 4. Test autonomous skill learning

The lifecycle is intentionally explicit:

1. Create a proposal from a verified task outcome.
2. Move it to testing.
3. Submit replay or sandbox scores.
4. Confirm it enters `awaiting_approval` only when the score reaches the threshold.
5. Approve it as the owner.
6. Confirm it is active and versioned.
7. Record evidence from later executions.
8. Roll it back if performance or safety degrades.

The unit test is:

```bash
cd backend
source .venv/bin/activate
pytest -q tests/test_extensions.py
```

To exercise the API with the server running:

```bash
export API=http://localhost:8000
export KEY=dev-rhb-key

# Propose a skill
curl -s -X POST "$API/api/skills/propose?task_id=task-1234&objective=Research%20and%20summarize" \
  -H "X-API-Key: $KEY" -H 'Content-Type: application/json' \
  -d '{"observations":["collect sources","verify claims","write report"]}'
```

Copy the returned skill ID, then run:

```bash
curl -s -X POST "$API/api/skills/SKILL_ID/test" -H "X-API-Key: $KEY"
curl -s -X POST "$API/api/skills/SKILL_ID/evaluate?scores=0.9&scores=0.95" -H "X-API-Key: $KEY"
curl -s -X POST "$API/api/skills/SKILL_ID/approve" -H "X-API-Key: $KEY"
curl -s -X POST "$API/api/skills/SKILL_ID/rollback" -H "X-API-Key: $KEY"
```

The frontend currently exposes the lifecycle visually through the self-improvement panel and the approval queue. The API is the authoritative path for v0.1 testing; the next UI milestone should add a dedicated Skills page with proposal details, test runs, score history, approval identity, and rollback controls.

## 5. Test browser/computer approval gating

```bash
SESSION=$(curl -s -X POST "$API/api/browser/sessions?purpose=research" -H "X-API-Key: $KEY" | python -c 'import json,sys; print(json.load(sys.stdin)["id"])')
curl -s -X POST "$API/api/browser/sessions/$SESSION/inspect?url=https%3A%2F%2Fexample.com" -H "X-API-Key: $KEY"
curl -s -X POST "$API/api/browser/sessions/$SESSION/actions?action=read%20page&risk=read_only" -H "X-API-Key: $KEY"
curl -s -X POST "$API/api/browser/sessions/$SESSION/actions?action=submit%20form&risk=external_action" -H "X-API-Key: $KEY"
curl -s -X DELETE "$API/api/browser/sessions/$SESSION" -H "X-API-Key: $KEY"
```

The read-only action is planned, while the external action returns `awaiting_approval`. This is the correct behavior until a real browser connector, domain allowlist, session isolation, and approval workflow are connected.

## 6. Test from the frontend

Start the API and frontend, open `http://localhost:3000`, and submit: `Research the current state of a topic and prepare a structured report.` The command center should show a completed task with a verified `web_research` step. Submit a second task with the API field `require_approval: true` to populate the human-approval queue. Approve or reject it from the UI and refresh the activity list.

Voice activation is available from the capability panel in browsers that support Web Speech recognition. The browser transcript is only an input convenience; it still enters the same task pipeline and does not bypass authentication, tool policy, or approval gates.

## 7. Recommended next milestones

The safest path to a more capable JARVIS-style system is to replace the in-memory repository with PostgreSQL persistence, move long-running work to Redis-backed workers, add a real provider adapter with structured outputs, then add isolated browser sessions and document ingestion. After that, introduce semantic memory, source citations, agent delegation, and a dedicated skill test runner. Each capability should be observable, permissioned, tested, and reversible before it becomes autonomous.
