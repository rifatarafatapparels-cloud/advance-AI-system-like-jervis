from uuid import uuid4
from app.domain.models import Approval, AuditEvent, Memory, Task, TaskStatus, now
from app.services.llm import get_provider
from app.services.repository import Repository
from app.tools.registry import ToolRegistry


class Orchestrator:
    def __init__(self, repo: Repository, tools: ToolRegistry) -> None:
        self.repo, self.tools = repo, tools
        self.provider = get_provider()

    def audit(self, task_id: str | None, event_type: str, payload: dict, actor: str = "system") -> None:
        self.repo.audit.append(AuditEvent(id=str(uuid4()), task_id=task_id, event_type=event_type, actor=actor, payload=payload))

    async def run(self, task: Task) -> Task:
        task.status = TaskStatus.planning; task.updated_at = now(); self.audit(task.id, "task.planning", {})
        task.plan = await self.provider.make_plan(task.objective, [x.name for x in self.tools.infos()])
        if any(step.tool == "web_research" for step in task.plan.steps):
            # Medium-risk external research is observable and can be gated by the caller.
            pass
        task.status = TaskStatus.running; self.audit(task.id, "task.running", {"steps": len(task.plan.steps)})
        observations: list[str] = []
        for step in task.plan.steps:
            step.status = "running"; self.audit(task.id, "tool.started", {"tool": step.tool})
            try:
                result = await self.tools.get(step.tool).execute(step.input, self.repo, task.conversation_id)
                step.observation = result; step.verification = "Tool returned successfully; production verifiers can add citations/schema checks."; step.status = "verified"
                observations.append(result); self.audit(task.id, "tool.verified", {"tool": step.tool})
            except Exception as exc:
                step.status = "failed"; task.status = TaskStatus.failed; task.error = str(exc); self.audit(task.id, "tool.failed", {"tool": step.tool, "error": str(exc)}); return task
        task.result = await self.provider.synthesize(task.objective, observations)
        task.status = TaskStatus.completed; task.updated_at = now()
        if task.conversation_id:
            self.repo.memories[task.conversation_id].append(Memory(id=str(uuid4()), conversation_id=task.conversation_id, content=task.result, kind="episodic", importance=0.7))
            self.audit(task.id, "memory.written", {"conversation_id": task.conversation_id})
        self.audit(task.id, "task.completed", {})
        return task

    def request_approval(self, task: Task) -> Approval:
        approval = Approval(id=str(uuid4()), task_id=task.id, reason="Task requests human approval before executing tools.")
        self.repo.approvals[approval.id] = approval; task.status = TaskStatus.awaiting_approval; self.audit(task.id, "approval.requested", {"approval_id": approval.id})
        return approval
