"""Extension contracts for Layer 2 capability growth.

These interfaces keep the kernel domain-neutral and prevent pretending that
v0.1 already has broad intelligence, autonomous learning, or computer control.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class AgentProfile:
    name: str
    description: str
    capabilities: tuple[str, ...]

class AgentRegistry:
    def __init__(self) -> None: self._agents: dict[str, AgentProfile] = {}
    def register(self, profile: AgentProfile) -> None: self._agents[profile.name] = profile
    def list(self) -> list[AgentProfile]: return list(self._agents.values())

class ModelRouter(ABC):
    @abstractmethod
    def route(self, capability: str, context: dict[str, Any]) -> str: ...

class DefaultModelRouter(ModelRouter):
    def route(self, capability: str, context: dict[str, Any]) -> str:
        return "mock"  # Replace by capability-aware model policy in Layer 2.

class LearningEngine(ABC):
    @abstractmethod
    async def propose_skill(self, task_id: str, evidence: list[str]) -> dict[str, Any]: ...

class SafeLearningEngine(LearningEngine):
    async def propose_skill(self, task_id: str, evidence: list[str]) -> dict[str, Any]:
        return {"status":"proposal_only", "task_id":task_id, "requires_human_approval":True, "evidence_count":len(evidence)}

agents = AgentRegistry()
for name, description, capabilities in [
    ("ExecutiveAgent", "Coordinates objectives and delegates work.", ("delegation",)),
    ("ResearchAgent", "Collects and structures evidence from approved sources.", ("research",)),
    ("AnalystAgent", "Analyzes verified observations.", ("analysis",)),
    ("CoderAgent", "Plans software changes in a bounded workspace.", ("coding",)),
    ("PlannerAgent", "Decomposes objectives into executable steps.", ("planning",)),
    ("VerifierAgent", "Checks results against explicit acceptance criteria.", ("verification",)),
]: agents.register(AgentProfile(name, description, capabilities))
