from abc import ABC, abstractmethod
from typing import Any
from app.domain.models import ToolInfo
from app.services.repository import Repository


class Tool(ABC):
    info: ToolInfo

    @abstractmethod
    async def execute(self, payload: dict[str, Any], repo: Repository, conversation_id: str | None) -> str: ...


class MemoryRecallTool(Tool):
    info = ToolInfo(name="memory_recall", description="Recall persistent conversation memories.", risk="low", input_schema={"type": "object"})

    async def execute(self, payload: dict[str, Any], repo: Repository, conversation_id: str | None) -> str:
        memories = repo.list_memories(conversation_id or "default")
        return "\n".join(m.content for m in memories[:8]) or "No prior memories found."


class WebResearchTool(Tool):
    info = ToolInfo(name="web_research", description="Fetch public web sources for research tasks.", risk="medium", input_schema={"type": "object", "properties": {"query": {"type": "string"}}})

    async def execute(self, payload: dict[str, Any], repo: Repository, conversation_id: str | None) -> str:
        # v0.1 keeps network execution behind this boundary; production can add allowlists,
        # rate limiting, citation extraction, and a browser-backed implementation.
        query = payload.get("query", "")
        return f"Research placeholder for: {query}. Tool boundary is active; configure a provider/search backend for live sources."


class FileDocumentTool(Tool):
    info = ToolInfo(name="file_document", description="Read or transform user-provided documents.", risk="medium", input_schema={"type": "object"})

    async def execute(self, payload: dict[str, Any], repo: Repository, conversation_id: str | None) -> str:
        return "Document tool boundary is active; file storage and parsers plug in here."


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.info.name] = tool

    def get(self, name: str) -> Tool:
        if name not in self._tools:
            raise KeyError(f"Unknown tool: {name}")
        return self._tools[name]

    def infos(self) -> list[ToolInfo]:
        return [tool.info for tool in self._tools.values()]


registry = ToolRegistry()
from app.services.browser_computer import browser_adapter
from app.tools.computer_use_example import ClickComputerActionTool

for _tool in (MemoryRecallTool(), WebResearchTool(), FileDocumentTool(), ClickComputerActionTool(browser_adapter)):
    registry.register(_tool)
