from abc import ABC, abstractmethod
from app.domain.models import Plan, PlanStep


class LLMProvider(ABC):
    @abstractmethod
    async def make_plan(self, objective: str, available_tools: list[str]) -> Plan: ...

    @abstractmethod
    async def synthesize(self, objective: str, observations: list[str]) -> str: ...


class MockLLMProvider(LLMProvider):
    async def make_plan(self, objective: str, available_tools: list[str]) -> Plan:
        steps: list[PlanStep] = []
        if any(word in objective.lower() for word in ("research", "search", "latest", "compare")):
            steps.append(PlanStep(id="research-1", title="Research the objective", tool="web_research", input={"query": objective}))
        else:
            steps.append(PlanStep(id="memory-1", title="Recall relevant context", tool="memory_recall", input={}))
        return Plan(steps=steps, rationale="Created by the provider abstraction; replace MockLLMProvider with a hosted provider without changing orchestration.")

    async def synthesize(self, objective: str, observations: list[str]) -> str:
        evidence = "\n\n".join(observations) or "No tool observations were produced."
        return f"Objective: {objective}\n\nVerified observations:\n{evidence}"


def get_provider() -> LLMProvider:
    # Provider selection is intentionally centralized for future OpenAI/Anthropic/local adapters.
    return MockLLMProvider()
