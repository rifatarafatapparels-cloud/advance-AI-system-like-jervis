# RHB AI local app

This bundle runs RHB AI entirely on your computer. GitHub, cloud hosting, Docker, and external deployment are not required for the local workflow.

## Requirements

Install Python 3.11+ and Node.js 18+. PostgreSQL and Redis are optional for this v0.1 local mode because the development repository uses its local in-process state. They remain available through Docker Compose for the production topology.

## First run

Open a terminal in the extracted `agent-platform` folder and run:

```bash
./setup-local.sh
```

This creates `.env` if needed, creates the Python virtual environment, installs backend dependencies, installs frontend dependencies, and performs a production frontend build.

## Start RHB AI

```bash
./run-local.sh
```

The script starts the backend on `http://127.0.0.1:8000`, starts the RHB AI interface on `http://127.0.0.1:3000`, and opens the interface automatically when a desktop browser launcher is available. Press `Ctrl+C` in the terminal to stop both services.

The API documentation is at `http://127.0.0.1:8000/docs`. The local development owner key is `dev-rhb-key`; replace it in `.env` before using the application beyond your own machine.

## Import a public link into RHB AI

The command center includes an owner-only **Add a permitted public link** panel. The supplied Facebook Reel is prefilled there. Press **IMPORT LINK** to record its public metadata as a governed learning candidate, then evaluate and approve it through the learning API. RHB AI does not attempt to bypass Facebook login, CAPTCHA, private content, or other access controls.

## Open as an app

Open `http://127.0.0.1:3000` in Chrome or another Chromium browser and choose **Install RHB AI** from the browser menu. The PWA will open as a standalone RHB AI application with its icon. The file `rhb-ai.desktop` is also included as a Linux launcher template.

## Local files

The application remains in the folder you extracted. No GitHub account, repository, cloud deployment, or external hosting is needed. Logs are written to `/tmp/rhb-ai-backend.log` and `/tmp/rhb-ai-frontend.log` while the launcher is running.

## Online and offline modes

When the local backend is running, RHB AI supports the full v0.1 workflow: tasks, tools, memory, approvals, browser planning, compound-brain orchestration, and governed learning. When the computer is temporarily offline, the installed PWA can still open its cached command-center shell and display the interface. Network-dependent research, model-provider calls, and backend API operations require connectivity; offline mode does not pretend to provide live web knowledge.

The complete architecture visual is available at `docs/RHB-Advance-AI-Assistance-System.png`, with editable Mermaid source at `docs/RHB-Advance-AI-Assistance-System.mmd`.

## Troubleshooting

If port 3000 or 8000 is already in use, stop the process using that port and run the launcher again. If the browser does not open automatically, manually visit `http://127.0.0.1:3000`. If setup fails, rerun `./setup-local.sh` after checking that Python and Node.js are available on the PATH.
