from datetime import datetime, timezone
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


def now() -> datetime:
    return datetime.now(timezone.utc)


class TaskStatus(str, Enum):
    queued = "queued"
    planning = "planning"
    running = "running"
    awaiting_approval = "awaiting_approval"
    completed = "completed"
    failed = "failed"


class TaskCreate(BaseModel):
    objective: str = Field(min_length=3, max_length=4000)
    conversation_id: str | None = None
    require_approval: bool = False


class PlanStep(BaseModel):
    id: str
    title: str
    tool: str
    input: dict[str, Any] = Field(default_factory=dict)
    status: str = "pending"
    observation: str | None = None
    verification: str | None = None


class Plan(BaseModel):
    steps: list[PlanStep]
    rationale: str


class Task(BaseModel):
    id: str
    objective: str
    status: TaskStatus
    conversation_id: str | None = None
    plan: Plan | None = None
    result: str | None = None
    error: str | None = None
    created_at: datetime = Field(default_factory=now)
    updated_at: datetime = Field(default_factory=now)


class Approval(BaseModel):
    id: str
    task_id: str
    reason: str
    status: str = "pending"
    decided_by: str | None = None
    created_at: datetime = Field(default_factory=now)


class Memory(BaseModel):
    id: str
    conversation_id: str
    content: str
    kind: str = "working"
    importance: float = 0.5
    created_at: datetime = Field(default_factory=now)


class AuditEvent(BaseModel):
    id: str
    task_id: str | None
    event_type: str
    actor: str
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=now)


class ToolInfo(BaseModel):
    name: str
    description: str
    risk: str
    input_schema: dict[str, Any]
