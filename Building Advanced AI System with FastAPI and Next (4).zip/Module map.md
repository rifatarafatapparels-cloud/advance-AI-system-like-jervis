# Module map

- `frontend/` — Next.js command center; action-level progress, approvals, task results.
- `backend/app/api/` — REST/OpenAPI route surface.
- `backend/app/services/` — orchestration, provider abstraction, repository, worker and future extension contracts.
- `backend/app/tools/` — permission-aware universal tool registry.
- `database/` — PostgreSQL schema contract for users, conversations, tasks, agents, tools, memory, knowledge, skills, approvals and audit.
- `docker-compose.yml` — service topology for frontend, API, worker, PostgreSQL and Redis.
- `docs/` — architecture and Layer 2 migration notes.

The remaining domain folders from the long-term blueprint (knowledge, skills, integrations, observability) are represented by explicit service interfaces and database contracts in v0.1, avoiding empty pretend features while preserving stable seams.
