from app.services.skill_learning import SkillRegistry, AutonomousSkillLoop, SkillStatus
from app.services.browser_computer import BrowserComputerAdapter, BrowserPolicy, ComputerRisk

def test_skill_lifecycle_requires_approval_and_supports_rollback():
    registry = SkillRegistry(); loop = AutonomousSkillLoop(registry)
    skill = loop.propose_from_task('task-1234', 'Research and summarize', ['observation'])
    assert skill.status == SkillStatus.draft
    registry.request_testing(skill.id)
    registry.evaluate(skill.id, [0.9, 0.95])
    assert skill.status == SkillStatus.awaiting_approval
    registry.approve(skill.id, 'owner')
    assert skill.status == SkillStatus.active
    registry.rollback(skill.id)
    assert skill.status == SkillStatus.deprecated

def test_external_browser_action_is_gated():
    adapter = BrowserComputerAdapter(BrowserPolicy(allow_external_actions=False))
    session = adapter.start_session('test')
    decision = adapter.plan_action(session.id, 'submit form', ComputerRisk.external_action)
    assert decision['status'] == 'awaiting_approval'
