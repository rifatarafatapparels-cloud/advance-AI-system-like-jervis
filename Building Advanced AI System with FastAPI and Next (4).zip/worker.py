"""Background worker entrypoint.

The v0.1 API executes short tasks inline for deterministic local behavior. This
process is the seam for Redis-backed queues (RQ/Arq/Celery) and long-running
browser, voice, ingestion, or autonomous-learning jobs in the next milestone.
"""
import time

if __name__ == "__main__":
    print("RHB worker ready; connect Redis queue consumers here.")
    while True:
        time.sleep(30)
