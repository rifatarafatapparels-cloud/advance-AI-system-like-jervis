from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router
from app.core.config import settings

app = FastAPI(title="RHB Autonomous Agent Platform", version="0.1.0", description="Agent → plan → tool → observe → verify → remember → improve")
app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(router)

@app.get("/")
async def root():
    return {"name": "RHB Autonomous Agent Platform", "version": "0.1.0", "docs": "/docs"}
