import './globals.css';
import OfflineRegister from '../components/OfflineRegister';
export const metadata={title:'RHB AI · Command Center',description:'Autonomous work operating system',manifest:'/manifest.json',icons:{icon:'/rhb-ai-icon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><OfflineRegister/>{children}</body></html>}
