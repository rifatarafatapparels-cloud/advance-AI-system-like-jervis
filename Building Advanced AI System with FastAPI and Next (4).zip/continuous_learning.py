"""Continuous learning controller with bounded, auditable cycles.

The controller learns from approved sources and verified task outcomes. It does
not rewrite its own core, self-grant permissions, or activate skills silently.
A production deployment can invoke `run_cycle` from the Redis worker or a
controlled scheduler.
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import uuid4

class LearningCycleStatus(str, Enum):
    idle = "idle"
    collecting = "collecting"
    evaluating = "evaluating"
    awaiting_approval = "awaiting_approval"
    applied = "applied"
    failed = "failed"

def now() -> datetime:
    return datetime.now(timezone.utc)

@dataclass
class KnowledgeCandidate:
    id: str
    title: str
    source: str
    content: str
    confidence: float
    provenance: dict[str, Any] = field(default_factory=dict)
    approved: bool = False
    created_at: datetime = field(default_factory=now)

@dataclass
class LearningCycle:
    id: str
    trigger: str
    status: LearningCycleStatus = LearningCycleStatus.idle
    candidates: list[KnowledgeCandidate] = field(default_factory=list)
    evaluation: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=now)
    updated_at: datetime = field(default_factory=now)

class ContinuousLearningController:
    def __init__(self) -> None:
        self.cycles: dict[str, LearningCycle] = {}
        self.knowledge: dict[str, KnowledgeCandidate] = {}
        self.enabled = True

    def start_cycle(self, trigger: str = "manual") -> LearningCycle:
        cycle = LearningCycle(str(uuid4()), trigger, LearningCycleStatus.collecting)
        self.cycles[cycle.id] = cycle
        return cycle

    def collect(self, cycle_id: str, title: str, source: str, content: str, confidence: float, provenance: dict[str, Any] | None = None) -> KnowledgeCandidate:
        cycle = self.cycles[cycle_id]
        if cycle.status != LearningCycleStatus.collecting: raise ValueError("Cycle is not collecting")
        candidate = KnowledgeCandidate(str(uuid4()), title, source, content[:20000], max(0.0, min(1.0, confidence)), provenance or {})
        cycle.candidates.append(candidate)
        return candidate

    def evaluate(self, cycle_id: str, min_confidence: float = 0.8) -> LearningCycle:
        cycle = self.cycles[cycle_id]
        cycle.status = LearningCycleStatus.evaluating
        accepted = [c for c in cycle.candidates if c.confidence >= min_confidence and c.source]
        cycle.evaluation = {"candidate_count": len(cycle.candidates), "accepted_count": len(accepted), "min_confidence": min_confidence, "requires_approval": bool(accepted)}
        cycle.status = LearningCycleStatus.awaiting_approval if accepted else LearningCycleStatus.applied
        return cycle

    def approve(self, cycle_id: str, approver: str) -> LearningCycle:
        cycle = self.cycles[cycle_id]
        if cycle.status != LearningCycleStatus.awaiting_approval: raise ValueError("Cycle is not awaiting approval")
        for candidate in cycle.candidates:
            if candidate.confidence >= cycle.evaluation.get("min_confidence", .8):
                candidate.approved = True; self.knowledge[candidate.id] = candidate
        cycle.evaluation["approved_by"] = approver
        cycle.status = LearningCycleStatus.applied
        cycle.updated_at = now()
        return cycle

    def snapshot(self) -> dict[str, Any]:
        return {"enabled": self.enabled, "cycles": len(self.cycles), "knowledge_items": len(self.knowledge), "last_status": list(self.cycles.values())[-1].status.value if self.cycles else "idle"}

learning_controller = ContinuousLearningController()
