import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.services.repository import repo

client = TestClient(app, headers={"X-API-Key": "dev-rhb-key"})

@pytest.fixture(autouse=True)
def reset_repo():
    repo.tasks.clear(); repo.approvals.clear(); repo.memories.clear(); repo.audit.clear()

def test_health():
    response = client.get('/api/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'

def test_authentication_rejects_invalid_key():
    response = client.get('/api/tools', headers={'X-API-Key': 'not-the-key'})
    assert response.status_code == 401

def test_owner_only_access_rejects_missing_key():
    response = TestClient(app).get('/api/tools')
    assert response.status_code == 401

def test_complete_demo_workflow():
    response = client.post('/api/tasks', json={'objective':'Research a topic and prepare a structured report.', 'conversation_id':'demo'})
    assert response.status_code == 200
    task = response.json()
    assert task['status'] == 'completed'
    assert task['plan']['steps'][0]['tool'] == 'web_research'
    assert task['plan']['steps'][0]['status'] == 'verified'
    assert len(client.get('/api/memory/demo').json()) == 1
    event_types = {event['event_type'] for event in client.get('/api/audit').json()}
    assert {'task.planning','tool.verified','memory.written','task.completed'} <= event_types

def test_approval_gate():
    task = client.post('/api/tasks', json={'objective':'Do a sensitive action', 'require_approval':True}).json()
    assert task['status'] == 'awaiting_approval'
    approvals = client.get('/api/approvals').json()
    assert len(approvals) == 1
    decided = client.post(f"/api/approvals/{approvals[0]['id']}/decide?approved=False").json()
    assert decided['status'] == 'failed'

def test_tool_registry():
    names = {tool['name'] for tool in client.get('/api/tools').json()}
    assert {'web_research','memory_recall','file_document'} <= names
