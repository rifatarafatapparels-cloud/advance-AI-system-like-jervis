from collections import defaultdict
from app.domain.models import Approval, AuditEvent, Memory, Task


class Repository:
    def __init__(self) -> None:
        self.tasks: dict[str, Task] = {}
        self.approvals: dict[str, Approval] = {}
        self.memories: dict[str, list[Memory]] = defaultdict(list)
        self.audit: list[AuditEvent] = []

    def list_tasks(self) -> list[Task]:
        return sorted(self.tasks.values(), key=lambda x: x.created_at, reverse=True)

    def list_audit(self, task_id: str | None = None) -> list[AuditEvent]:
        events = [e for e in self.audit if task_id is None or e.task_id == task_id]
        return sorted(events, key=lambda x: x.created_at, reverse=True)

    def list_approvals(self) -> list[Approval]:
        return sorted(self.approvals.values(), key=lambda x: x.created_at, reverse=True)

    def list_memories(self, conversation_id: str) -> list[Memory]:
        return sorted(self.memories[conversation_id], key=lambda x: x.created_at, reverse=True)


repo = Repository()
