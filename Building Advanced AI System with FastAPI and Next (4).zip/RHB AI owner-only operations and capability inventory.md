# RHB AI owner-only operations and capability inventory

## Owner-only visibility

RHB AI is configured for owner-only operation. Every protected API route requires the exact `X-API-Key` configured in `API_KEY`; missing or incorrect credentials receive HTTP 401. The owner label is controlled by `OWNER_NAME`, while `OWNER_ONLY=true` documents the intended deployment posture. The frontend sends the key from `NEXT_PUBLIC_API_KEY`, so the app should be bound to localhost or placed behind a private network in production. Never commit `.env` or expose the owner key in a public client build.

Set a strong private value before using the system beyond local testing:

```dotenv
APP_ENV=production
API_KEY=generate-a-long-random-secret
OWNER_NAME=RHB
OWNER_ONLY=true
CORS_ORIGINS=https://your-private-domain.example
```

For stronger isolation, add a reverse proxy or VPN, disable public registration, place the API and database on private networks, rotate the key periodically, and add real user identity/RBAC before connecting external tools. Owner-only visibility is an authorization boundary, not a substitute for network security.

## Existing tools and capabilities

| Surface | Current implementation | Current safety state |
|---|---|---|
| `memory_recall` | Retrieves recent conversation memories | Low risk |
| `web_research` | Controlled research-tool boundary | Medium risk; provider integration required for live sources |
| `file_document` | File/document tool boundary | Medium risk; storage/parser integration required |
| `computer_click` | Custom browser/computer action example | External action; approval/policy gated |
| Agent Registry | Executive, Research, Analyst, Coder, Planner, Verifier profiles | Modular registry |
| Model Router | Provider-selection interface | Mock provider in v0.1 |
| Skill Registry | Versioned procedures and evidence | Approval + rollback required |
| Browser Adapter | Sessions, inspect, action planning, stop | Permissioned dry-run |
| Voice Gateway | Browser speech seam plus backend STT/TTS interface | Browser provider in v0.1 |
| Memory | Episodic in-memory repository plus PostgreSQL schema | Durable migration path defined |
| Knowledge | PostgreSQL knowledge-item schema contract | Ingestion pipeline is next milestone |
| Background Jobs | Redis topology and worker entrypoint | Queue adapter is next milestone |
| Security | API key, risk levels, approval endpoint, audit events | Owner-only API enforced |

The platform does not yet contain all world knowledge or guarantee instant solutions to every problem. It provides the architecture for adding approved knowledge packages, live research, document ingestion, semantic retrieval, and verified skills without rebuilding the kernel.

## Continuous learning and the compound brain

`continuous_learning.py` provides bounded learning cycles for approved knowledge candidates. A cycle collects provenance, evaluates confidence, pauses for owner approval when candidates qualify, and only then adds them to the knowledge store. It is designed to run from the Redis worker on a controlled cadence; it does not rewrite its own core or activate permissions.

`compound_brain.py` provides a fast-response composition layer. It runs Planner, Researcher, Analyst, and SafetyVerifier lanes concurrently, aggregates their findings, and synthesizes one result. This is an architecture for combining specialist models and compute pools; it is not a literal supercomputer and does not guarantee that every answer is correct within seconds. Production routing can send each lane to a different model, local GPU service, private knowledge store, or high-compute queue.

The learning status endpoint is `/api/learning/status`. The compound-brain endpoint is `POST /api/brain/solve?objective=...`; both require the owner API key.

For the supplied Facebook Reel, use `POST /api/learning/import-url?url=https%3A%2F%2Fwww.facebook.com%2Fshare%2Fr%2F1KGQqm3F1m%2F`. The importer records the public metadata visible without login and creates an approval-gated candidate. It does not bypass Facebook authentication or private content restrictions.

## Implementing a custom computer-use action tool

A tool must describe its name, purpose, risk, and input schema, then implement the asynchronous `execute()` contract. The example lives in `backend/app/tools/computer_use_example.py`:

```python
class ClickComputerActionTool(Tool):
    info = ToolInfo(
        name="computer_click",
        description="Plan a click in an approved browser session; external side effects require approval.",
        risk="external_action",
        input_schema={"type":"object", "required":["session_id","target"]},
    )

    async def execute(self, payload, repo, conversation_id):
        if not payload.get("approved", False):
            return "ACTION_AWAITING_APPROVAL"
        decision = self.adapter.plan_action(...)
        if decision["status"] == "awaiting_approval":
            return "ACTION_BLOCKED_BY_POLICY"
        return "ACTION_PLANNED"
```

Register it with `registry.register(ClickComputerActionTool(browser_adapter))`. The registry already registers the example in v0.1. A production adapter should additionally validate the session owner, enforce domain allowlists, isolate browser contexts, log screenshots/action metadata, prohibit credential extraction, and require explicit confirmation immediately before any irreversible side effect.

## Finished API process

Start the backend and frontend using the commands in `README.md`, then export the owner key:

```bash
export API=http://localhost:8000
export KEY=dev-rhb-key
```

Check owner-only access:

```bash
curl -i "$API/api/tools"
curl -s "$API/api/tools" -H "X-API-Key: $KEY"
```

Create a task and observe the complete kernel loop:

```bash
curl -s -X POST "$API/api/tasks" \
  -H "X-API-Key: $KEY" -H 'Content-Type: application/json' \
  -d '{"objective":"Research a topic and prepare a structured report.","conversation_id":"rhb-owner"}'
```

The result should include a plan, a verified tool step, a completed status, and a memory entry available at `/api/memory/rhb-owner`. Audit events are available at `/api/audit`.

Test the custom browser action:

```bash
SESSION=$(curl -s -X POST "$API/api/browser/sessions?purpose=owner-test" -H "X-API-Key: $KEY" | python -c 'import json,sys; print(json.load(sys.stdin)["id"])')
curl -s -X POST "$API/api/browser/sessions/$SESSION/actions?action=submit%20form\&risk=external_action" -H "X-API-Key: $KEY"
```

The response must remain `awaiting_approval` while external actions are disabled. This is intentional.

## Skill-learning and approval workflow

Use the existing skill endpoints in order: `/api/skills/propose`, `/api/skills/{id}/test`, `/api/skills/{id}/evaluate`, `/api/skills/{id}/approve`, and `/api/skills/{id}/rollback`. A passing evaluation moves the skill to `awaiting_approval`; only the owner approval endpoint activates it. A rollback deprecates the active version. The browser/computer approval flow follows the same principle: plan first, gate external side effects, execute only after policy and owner approval are satisfied.

## Validation

Run the backend suite and frontend build:

```bash
cd backend && source .venv/bin/activate && pytest -q
cd ../frontend && npm run build
```

The tests cover health, missing/invalid authentication, task creation, orchestration, tool registration, memory, audit events, approval rejection, skill lifecycle, and browser action gating.

## What to add next for a stronger JARVIS

The highest-value next steps are durable PostgreSQL repositories, Redis-backed long-running jobs, a real structured-output LLM adapter, citations and document ingestion, semantic memory, agent delegation with retries/timeouts, isolated browser connectors, server-side STT/TTS, and policy/RBAC enforcement. Each addition should remain owner-scoped, observable, approval-gated where necessary, and reversible.
