#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if ! command -v python3 >/dev/null 2>&1; then echo "Python 3 is required."; exit 1; fi
if ! command -v node >/dev/null 2>&1; then echo "Node.js is required."; exit 1; fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created local .env from .env.example"
fi

if [ -d backend/.venv ] && ! backend/.venv/bin/python -m pip --version >/dev/null 2>&1; then
  echo "Repairing stale Python environment..."
  rm -rf backend/.venv
fi
if [ ! -d backend/.venv ]; then python3 -m venv backend/.venv; fi
backend/.venv/bin/python -m pip install --upgrade pip >/dev/null
backend/.venv/bin/pip install -q -r backend/requirements.txt python-docx

cd frontend
if [ ! -d node_modules ]; then npm install; fi
npm run build
cd "$ROOT"
chmod +x run-local.sh
printf '\nRHB AI local build complete. Start it with: ./run-local.sh\n'
