"""Example: registering a custom computer-use action safely.

This tool demonstrates the required contract. It plans an action through the
browser adapter and refuses to execute external side effects without approval.
"""
from typing import Any
from app.domain.models import ToolInfo
from app.services.browser_computer import BrowserComputerAdapter, ComputerRisk
from app.services.repository import Repository
from app.tools.registry import Tool

class ClickComputerActionTool(Tool):
    info = ToolInfo(
        name="computer_click",
        description="Plan a click in an approved browser session; external side effects require approval.",
        risk="external_action",
        input_schema={"type":"object","required":["session_id","target"],"properties":{"session_id":{"type":"string"},"target":{"type":"string"},"approved":{"type":"boolean"}}},
    )

    def __init__(self, adapter: BrowserComputerAdapter):
        self.adapter = adapter

    async def execute(self, payload: dict[str, Any], repo: Repository, conversation_id: str | None) -> str:
        session_id = payload["session_id"]
        target = payload["target"]
        approved = payload.get("approved", False)
        if not approved:
            decision = self.adapter.plan_action(session_id, f"click {target}", ComputerRisk.external_action)
            repo.audit.append({"event_type":"computer.action.awaiting_approval","payload":decision})
            return "ACTION_AWAITING_APPROVAL: " + str(decision)
        decision = self.adapter.plan_action(session_id, f"click {target}", ComputerRisk.external_action)
        if decision["status"] == "awaiting_approval":
            return "ACTION_BLOCKED_BY_POLICY: owner approval and an enabled policy are required"
        return "ACTION_PLANNED: " + str(decision)

# Registration example:
# registry.register(ClickComputerActionTool(browser_adapter))
