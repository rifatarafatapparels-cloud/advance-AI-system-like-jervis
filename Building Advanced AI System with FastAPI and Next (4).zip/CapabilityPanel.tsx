"use client";
import { useState } from "react";
export default function CapabilityPanel(){
 const [listening,setListening]=useState(false); const [spoken,setSpoken]=useState("");
 function listen(){ const Speech=(window as any).SpeechRecognition||(window as any).webkitSpeechRecognition; if(!Speech){setSpoken("Browser voice recognition is unavailable; configure a server STT provider.");return} const recognition=new Speech(); recognition.lang="en-US"; recognition.onstart=()=>setListening(true); recognition.onend=()=>setListening(false); recognition.onresult=(e:any)=>setSpoken(e.results[0][0].transcript); recognition.start(); }
 return <div className="cap-panel"><div><span className="cap-dot"/> Voice extension <small>{listening?"LISTENING":"READY"}</small></div><button className="ghost" onClick={listen}>{listening?"LISTENING…":"ACTIVATE VOICE"}</button><div><span className="cap-dot blue"/> Browser/computer extension <small>PERMISSIONED DRY-RUN</small></div><div className="cap-note">No external action runs without an approval gate.</div>{spoken&&<div className="voice-result">“{spoken}”</div>}</div>
}
