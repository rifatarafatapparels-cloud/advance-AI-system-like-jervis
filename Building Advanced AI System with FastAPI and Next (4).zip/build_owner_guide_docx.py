from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from pathlib import Path

root = Path('/home/ubuntu/agent-platform')
doc = Document()
section = doc.sections[0]
section.top_margin = Inches(.7); section.bottom_margin = Inches(.7); section.left_margin = Inches(.8); section.right_margin = Inches(.8)
styles = doc.styles
styles['Normal'].font.name = 'Aptos'; styles['Normal'].font.size = Pt(10.5)
styles['Title'].font.name = 'Aptos Display'; styles['Title'].font.size = Pt(28)
styles['Heading 1'].font.name = 'Aptos Display'; styles['Heading 1'].font.size = Pt(18)
styles['Heading 2'].font.name = 'Aptos'; styles['Heading 2'].font.size = Pt(13)

p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('RHB AI').bold = True
p = doc.add_paragraph(); p.style = 'Title'; p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Owner-Only Operations and Capability Guide')
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Version 0.1 · Prepared for RHB').italic = True

def heading(text, level=1): doc.add_heading(text, level=level)
def para(text): doc.add_paragraph(text)
def bullets(items):
    for item in items: doc.add_paragraph(item, style='List Bullet')
def code(text):
    p=doc.add_paragraph(); r=p.add_run(text); r.font.name='Consolas'; r.font.size=Pt(9); p.paragraph_format.left_indent=Inches(.25)

heading('1. Owner-only visibility')
para('RHB AI is configured for owner-only operation. Every protected API route requires the exact X-API-Key configured in API_KEY; missing or incorrect credentials receive HTTP 401. OWNER_NAME identifies the owner label and OWNER_ONLY=true documents the intended deployment posture. Keep the frontend and API on localhost or a private network until stronger identity and RBAC are installed.')
code('APP_ENV=production\nAPI_KEY=generate-a-long-random-secret\nOWNER_NAME=RHB\nOWNER_ONLY=true\nCORS_ORIGINS=https://your-private-domain.example')
para('Owner-only visibility is an authorization boundary, not a complete security program. For production, add a private network or VPN, rotate secrets, restrict CORS, disable public registration, isolate the database, and add real identity/RBAC before connecting external tools.')

heading('2. Existing tools and knowledge surfaces')
table = doc.add_table(rows=1, cols=3); table.style='Table Grid'
for cell, text in zip(table.rows[0].cells, ['Surface','Current implementation','Safety/state']): cell.text=text
rows=[('memory_recall','Recent conversation memories','Low risk'),('web_research','Controlled research boundary','Medium risk; live provider required'),('file_document','File/document boundary','Medium risk; parser/storage integration required'),('computer_click','Custom computer-use action example','External action; approval gated'),('Agent Registry','Executive, Research, Analyst, Coder, Planner, Verifier','Modular'),('Model Router','Provider-selection interface','Mock provider in v0.1'),('Skill Registry','Versioned procedures and evidence','Approval + rollback'),('Browser Adapter','Sessions, inspect, action planning, stop','Permissioned dry-run'),('Voice Gateway','Browser speech seam + backend interface','Browser provider'),('Memory/Knowledge','Episodic memory + PostgreSQL contracts','Persistence/ingestion next'),('Security/Audit','API key, risk levels, approvals, audit events','Owner-only enforced')]
for row in rows:
    cells=table.add_row().cells
    for cell,text in zip(cells,row): cell.text=text

heading('3. Custom computer-use action tool')
para('A tool declares its name, purpose, risk, and input schema, then implements the asynchronous execute() contract. RHB AI registers computer_click in v0.1 through backend/app/tools/computer_use_example.py. It plans actions through the browser adapter and returns ACTION_AWAITING_APPROVAL until owner approval and policy permit the side effect.')
code('class ClickComputerActionTool(Tool):\n    info = ToolInfo(name="computer_click", risk="external_action", ...)\n\n    async def execute(self, payload, repo, conversation_id):\n        if not payload.get("approved", False):\n            return "ACTION_AWAITING_APPROVAL"\n        decision = self.adapter.plan_action(...)\n        if decision["status"] == "awaiting_approval":\n            return "ACTION_BLOCKED_BY_POLICY"\n        return "ACTION_PLANNED"')
para('Production implementations must validate session ownership, enforce domain allowlists, isolate browser contexts, prohibit credential extraction, log action metadata, and require confirmation immediately before irreversible effects.')

heading('4. Finished API process')
code('export API=http://localhost:8000\nexport KEY=dev-rhb-key\ncurl -i "$API/api/tools"\ncurl -s "$API/api/tools" -H "X-API-Key: $KEY"')
para('Create a task with the owner key. A research objective runs through planning, tool execution, observation, verification, memory, and audit logging.')
code('curl -s -X POST "$API/api/tasks" \\\n  -H "X-API-Key: $KEY" -H "Content-Type: application/json" \\\n  -d \'{"objective":"Research a topic and prepare a structured report.","conversation_id":"rhb-owner"}\'')
para('Audit events are available at /api/audit and memories at /api/memory/rhb-owner. Missing or invalid keys must return HTTP 401.')

heading('5. Skill-learning and approval workflow')
bullets(['Propose a skill from a verified outcome.', 'Move the proposal to testing.', 'Submit replay or sandbox scores.', 'Confirm a passing evaluation enters awaiting_approval.', 'Approve as the owner to activate the version.', 'Record evidence from later executions.', 'Rollback when performance or safety degrades.'])
code('pytest -q backend/tests/test_extensions.py')

heading('6. Voice and knowledge growth')
para('Voice is another authenticated input channel. Browser speech recognition is available in supported browsers, while the backend VoiceGateway accepts future STT/TTS providers. Voice commands use the same task, tool, security, and approval pipeline as typed commands. RHB AI does not ship with all world knowledge; it ships with the registry and provenance architecture needed to add approved research, documents, semantic memory, and domain packages safely.')

heading('7. Continuous learning and the compound brain')
para('The continuous learning controller provides bounded cycles for approved knowledge candidates. It collects provenance, evaluates confidence, pauses for owner approval when candidates qualify, and only then adds candidates to the knowledge store. It does not rewrite the core or grant itself permissions. The compound brain runs Planner, Researcher, Analyst, and SafetyVerifier lanes concurrently, then synthesizes their findings. This is a composition architecture for specialist models and compute pools, not a literal supercomputer and not a guarantee of perfect answers within seconds.')
code('GET  /api/learning/status\nPOST /api/learning/cycles\nPOST /api/learning/cycles/{cycle_id}/collect\nPOST /api/learning/cycles/{cycle_id}/evaluate\nPOST /api/learning/cycles/{cycle_id}/approve\nPOST /api/brain/solve?objective=Design%20a%20safe%20workflow')

heading('8. Validation and next steps')
code('cd backend && source .venv/bin/activate && pytest -q\ncd ../frontend && npm run build')
para('The recommended next milestones are durable PostgreSQL repositories, Redis-backed long-running jobs, real structured-output LLM adapters, citations and document ingestion, semantic memory, agent delegation, isolated browser connectors, server-side STT/TTS, and policy/RBAC enforcement. Every new capability should remain owner-scoped, observable, approval-gated where necessary, and reversible.')

heading('Appendix: Source files')
for path in ['backend/app/core/config.py','backend/app/api/routes.py','backend/app/tools/registry.py','backend/app/tools/computer_use_example.py','backend/app/services/browser_computer.py','backend/app/services/voice.py','backend/app/services/skill_learning.py','docs/RHB_AI_OWNER_OPERATIONS.md']:
    doc.add_paragraph(str(path), style='List Bullet')

out = root / 'docs' / 'RHB_AI_OWNER_OPERATIONS.docx'
doc.save(out)
print(out)
