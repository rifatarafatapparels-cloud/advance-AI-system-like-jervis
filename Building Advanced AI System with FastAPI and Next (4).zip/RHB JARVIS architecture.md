# RHB JARVIS architecture

## Kernel loop

`User → Intent → Plan → Agent/Tool selection → Execution → Observation → Verification → Memory → Result` is implemented in `backend/app/services/orchestrator.py`. The UI exposes action-level progress only; it does not expose private chain-of-thought.

## Boundaries

| Boundary | v0.1 implementation | Extension path |
|---|---|---|
| Model routing | `LLMProvider` + deterministic mock provider | OpenAI, Anthropic, local/private, vision, speech adapters |
| Tools | Registry with risk/schema metadata | Browser, computer, code sandbox, data, email, calendar plugins |
| Persistence | Repository contract + PostgreSQL schema | Async SQLAlchemy/ Alembic repositories and vector retrieval |
| Background work | Worker process seam + Redis topology | Arq/RQ/Celery queue, retries, timeouts, cancellation |
| Agents | Orchestrator-compatible plan steps | Registered Executive, Research, Analyst, Coder, Planner, Verifier agents |
| Learning | Skill and knowledge tables contract | Research → procedure extraction → sandbox test → evaluation → approval |
| Security | API key, risk metadata, human approval API, audit trail | RBAC, per-tool scopes, secret vault, emergency stop, policy engine |

## Safety posture

The system is intentionally not advertised as able to solve every problem instantly. Autonomous operation must be bounded by authorization, tool permissions, verifiable observations, and human approval for sensitive actions. The web research tool is a controlled integration boundary; it does not grant arbitrary system access.

## Autonomous skill acquisition

`skill_learning.py` implements a reversible learning lifecycle. A verified task can produce a versioned skill proposal. The proposal enters replay testing, receives scored evaluation, requests human approval, and only then becomes active. Evidence is retained for later improvement, while rollback deprecates the active version. The loop cannot grant itself new permissions or activate unverified procedures.

## Browser, computer, and voice extensions

`browser_computer.py` defines sessions, inspection, action planning, risk classification, domain policy, and stop controls. Read-only actions can be planned immediately; external or high-impact actions return `awaiting_approval` unless explicitly enabled by policy. `voice.py` provides a provider abstraction. The initial UI uses browser Web Speech recognition and speech-synthesis seams; server-side STT/TTS providers can be added later.

## RHB AI app shell

The Next.js frontend is branded as **RHB AI**, includes `manifest.json`, and ships a scalable `rhb-ai-icon.svg`. In a Chromium-based browser, installing the PWA creates a standalone app window with the RHB AI icon.

## Continuous learning and compound brain

`continuous_learning.py` provides bounded, provenance-aware knowledge cycles. It collects candidates, evaluates confidence, pauses for owner approval, and applies only approved items. `compound_brain.py` runs four bounded specialist lanes concurrently and synthesizes their observations. This creates a fast compound response path while preserving verification, auditability, and the distinction between composition architecture and literal supercomputer capability.

## Production migration sequence

1. Replace the in-memory repository with PostgreSQL repositories and migrations.
2. Move long-running execution to the Redis worker with durable task state and cancellation.
3. Add real provider adapters and model routing by task capability.
4. Add registered agents and parallel/subtask execution with timeouts and retry policy.
5. Add source citations, document ingestion, semantic memory, and knowledge provenance.
6. Add policy/RBAC enforcement and a kill switch before enabling external actions.
