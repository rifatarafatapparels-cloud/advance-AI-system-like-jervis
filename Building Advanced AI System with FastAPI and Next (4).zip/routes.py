from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import APIKeyHeader
from app.core.config import settings
from app.domain.models import Task, TaskCreate, TaskStatus, Memory, AuditEvent
from app.services.orchestrator import Orchestrator
from app.services.repository import repo
from app.tools.registry import registry
from app.services.skill_learning import skill_loop, skill_registry
from app.services.browser_computer import browser_adapter, ComputerRisk
from app.services.voice import voice_gateway
from app.services.continuous_learning import learning_controller
from app.services.compound_brain import compound_brain
from app.services.link_import import import_public_link

router = APIRouter(prefix="/api")
key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def auth(key: str | None = Depends(key_header)) -> str:
    if key != settings.api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return settings.owner_name


@router.get("/health")
async def health() -> dict:
    return {"status": "ok", "service": "rhb-agent-platform", "version": "0.1.0"}


@router.get("/tools")
async def tools(_: str = Depends(auth)):
    return registry.infos()


@router.get("/tasks")
async def tasks(_: str = Depends(auth)):
    return repo.list_tasks()


@router.post("/tasks", response_model=Task)
async def create_task(payload: TaskCreate, _: str = Depends(auth)):
    task = Task(id=str(uuid4()), objective=payload.objective, status=TaskStatus.queued, conversation_id=payload.conversation_id)
    repo.tasks[task.id] = task
    orchestrator = Orchestrator(repo, registry)
    if payload.require_approval:
        orchestrator.request_approval(task)
    else:
        await orchestrator.run(task)
    return task


@router.get("/tasks/{task_id}", response_model=Task)
async def get_task(task_id: str, _: str = Depends(auth)):
    if task_id not in repo.tasks: raise HTTPException(status_code=404, detail="Task not found")
    return repo.tasks[task_id]


@router.get("/approvals")
async def approvals(_: str = Depends(auth)):
    return repo.list_approvals()


@router.post("/approvals/{approval_id}/decide")
async def decide_approval(approval_id: str, approved: bool, _: str = Depends(auth)):
    approval = repo.approvals.get(approval_id)
    if not approval: raise HTTPException(status_code=404, detail="Approval not found")
    approval.status = "approved" if approved else "rejected"; approval.decided_by = "api-user"
    task = repo.tasks[approval.task_id]
    if approved: await Orchestrator(repo, registry).run(task)
    else: task.status = TaskStatus.failed; task.error = "Human approval rejected"
    return task


@router.get("/memory/{conversation_id}", response_model=list[Memory])
async def memory(conversation_id: str, _: str = Depends(auth)):
    return repo.list_memories(conversation_id)


@router.get("/audit", response_model=list[AuditEvent])
async def audit(task_id: str | None = None, _: str = Depends(auth)):
    return repo.list_audit(task_id)


@router.get("/agents")
async def agents(_: str = Depends(auth)):
    from app.services.extensions import agents as agent_registry
    return agent_registry.list()


@router.get("/skills")
async def skills(_: str = Depends(auth)):
    return list(skill_registry.skills.values())


@router.post("/skills/propose")
async def propose_skill(task_id: str, objective: str, observations: list[str], _: str = Depends(auth)):
    skill = skill_loop.propose_from_task(task_id, objective, observations)
    return skill


@router.post("/skills/{skill_id}/test")
async def test_skill(skill_id: str, _: str = Depends(auth)):
    return skill_registry.request_testing(skill_id)


@router.post("/skills/{skill_id}/evaluate")
async def evaluate_skill(skill_id: str, scores: list[float], _: str = Depends(auth)):
    return skill_registry.evaluate(skill_id, scores)


@router.post("/skills/{skill_id}/approve")
async def approve_skill(skill_id: str, _: str = Depends(auth)):
    return skill_registry.approve(skill_id, "api-user")


@router.post("/skills/{skill_id}/rollback")
async def rollback_skill(skill_id: str, _: str = Depends(auth)):
    return skill_registry.rollback(skill_id)


@router.get("/capabilities")
async def capabilities(_: str = Depends(auth)):
    return {"browser_computer": {"status": "ready", "mode": "permissioned-dry-run"}, "voice": {"status": "ready", "mode": "browser-provider"}}


@router.post("/browser/sessions")
async def start_browser_session(purpose: str, _: str = Depends(auth)):
    return browser_adapter.start_session(purpose)


@router.post("/browser/sessions/{session_id}/inspect")
async def inspect_browser_session(session_id: str, url: str, _: str = Depends(auth)):
    return browser_adapter.inspect(session_id, url)


@router.post("/browser/sessions/{session_id}/actions")
async def plan_browser_action(session_id: str, action: str, risk: ComputerRisk = ComputerRisk.read_only, _: str = Depends(auth)):
    return browser_adapter.plan_action(session_id, action, risk)


@router.delete("/browser/sessions/{session_id}")
async def stop_browser_session(session_id: str, _: str = Depends(auth)):
    return browser_adapter.stop_session(session_id)


@router.get("/learning/status")
async def learning_status(_: str = Depends(auth)):
    return learning_controller.snapshot()


@router.post("/learning/cycles")
async def start_learning_cycle(trigger: str = "manual", _: str = Depends(auth)):
    return learning_controller.start_cycle(trigger)


@router.post("/learning/cycles/{cycle_id}/collect")
async def collect_learning_candidate(cycle_id: str, title: str, source: str, content: str, confidence: float = 0.5, _: str = Depends(auth)):
    return learning_controller.collect(cycle_id, title, source, content, confidence, {"actor": "RHB"})


@router.post("/learning/cycles/{cycle_id}/evaluate")
async def evaluate_learning_cycle(cycle_id: str, min_confidence: float = 0.8, _: str = Depends(auth)):
    return learning_controller.evaluate(cycle_id, min_confidence)


@router.post("/learning/cycles/{cycle_id}/approve")
async def approve_learning_cycle(cycle_id: str, _: str = Depends(auth)):
    return learning_controller.approve(cycle_id, settings.owner_name)


@router.post("/learning/import-url")
async def import_learning_url(url: str, owner: str = Depends(auth)):
    try:
        return import_public_link(url, owner)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/brain/solve")
async def compound_brain_solve(objective: str, _: str = Depends(auth)):
    return await compound_brain.solve(objective)
