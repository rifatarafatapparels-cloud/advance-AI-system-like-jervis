"""Governed autonomous skill acquisition.

The loop can propose and evaluate improvements, but activation is explicit and
reversible. It never self-grants permissions or silently changes active skills.
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import uuid4


def now() -> datetime:
    return datetime.now(timezone.utc)


class SkillStatus(str, Enum):
    discovered = "discovered"
    draft = "draft"
    testing = "testing"
    awaiting_approval = "awaiting_approval"
    verified = "verified"
    active = "active"
    deprecated = "deprecated"
    rejected = "rejected"


@dataclass
class SkillEvidence:
    task_id: str
    observation: str
    outcome: str
    score: float
    verifier: str = "system"
    created_at: datetime = field(default_factory=now)


@dataclass
class SkillVersion:
    version: int
    procedure: dict[str, Any]
    required_tools: list[str]
    risk_level: str
    tests: list[dict[str, Any]]
    status: SkillStatus = SkillStatus.draft
    score: float | None = None
    created_at: datetime = field(default_factory=now)


@dataclass
class Skill:
    id: str
    name: str
    description: str
    domain: str
    status: SkillStatus = SkillStatus.discovered
    versions: list[SkillVersion] = field(default_factory=list)
    evidence: list[SkillEvidence] = field(default_factory=list)
    active_version: int | None = None
    updated_at: datetime = field(default_factory=now)


class SkillRegistry:
    def __init__(self) -> None:
        self.skills: dict[str, Skill] = {}

    def register_proposal(self, name: str, description: str, domain: str, procedure: dict[str, Any], required_tools: list[str], risk_level: str, tests: list[dict[str, Any]]) -> Skill:
        skill = Skill(str(uuid4()), name, description, domain)
        skill.versions.append(SkillVersion(1, procedure, required_tools, risk_level, tests))
        skill.status = SkillStatus.draft
        self.skills[skill.id] = skill
        return skill

    def add_evidence(self, skill_id: str, evidence: SkillEvidence) -> Skill:
        skill = self.skills[skill_id]
        skill.evidence.append(evidence)
        skill.updated_at = now()
        return skill

    def request_testing(self, skill_id: str) -> Skill:
        skill = self.skills[skill_id]
        if not skill.versions: raise ValueError("Skill has no version")
        skill.status = SkillStatus.testing
        skill.versions[-1].status = SkillStatus.testing
        return skill

    def evaluate(self, skill_id: str, test_results: list[float], minimum_score: float = 0.8) -> Skill:
        skill = self.skills[skill_id]
        score = sum(test_results) / len(test_results) if test_results else 0.0
        version = skill.versions[-1]
        version.score = score
        if score >= minimum_score:
            version.status = SkillStatus.verified
            skill.status = SkillStatus.awaiting_approval
        else:
            version.status = SkillStatus.rejected
            skill.status = SkillStatus.draft
        return skill

    def approve(self, skill_id: str, approver: str) -> Skill:
        skill = self.skills[skill_id]
        version = skill.versions[-1]
        if skill.status != SkillStatus.awaiting_approval or version.status != SkillStatus.verified:
            raise ValueError("Only verified skills awaiting approval can be activated")
        skill.active_version = version.version
        version.status = SkillStatus.active
        skill.status = SkillStatus.active
        skill.updated_at = now()
        return skill

    def rollback(self, skill_id: str) -> Skill:
        skill = self.skills[skill_id]
        active = next((v for v in skill.versions if v.version == skill.active_version), None)
        if active: active.status = SkillStatus.deprecated
        skill.active_version = None
        skill.status = SkillStatus.deprecated
        return skill


class AutonomousSkillLoop:
    """Turns verified task outcomes into proposals, never directly into authority."""
    def __init__(self, registry: SkillRegistry) -> None:
        self.registry = registry

    def propose_from_task(self, task_id: str, objective: str, observations: list[str]) -> Skill:
        return self.registry.register_proposal(
            name=f"procedure-{task_id[:8]}",
            description=f"Candidate procedure extracted from: {objective}",
            domain="general",
            procedure={"objective": objective, "steps": observations},
            required_tools=[],
            risk_level="normal",
            tests=[{"type": "replay", "task_id": task_id}],
        )

    def self_improve(self, skill_id: str, task_id: str, observation: str, outcome: str, score: float) -> Skill:
        """Record feedback; policy changes remain versioned and approval-gated."""
        return self.registry.add_evidence(skill_id, SkillEvidence(task_id, observation, outcome, score))


skill_registry = SkillRegistry()
skill_loop = AutonomousSkillLoop(skill_registry)
