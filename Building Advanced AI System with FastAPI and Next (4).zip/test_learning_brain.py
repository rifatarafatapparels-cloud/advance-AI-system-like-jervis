import pytest
from app.services.continuous_learning import ContinuousLearningController, LearningCycleStatus
from app.services.compound_brain import CompoundBrain


def test_continuous_learning_requires_approval_for_accepted_knowledge():
    controller = ContinuousLearningController()
    cycle = controller.start_cycle('manual')
    controller.collect(cycle.id, 'Verified item', 'owner-source', 'content', .95)
    controller.evaluate(cycle.id)
    assert cycle.status == LearningCycleStatus.awaiting_approval
    controller.approve(cycle.id, 'RHB')
    assert cycle.status == LearningCycleStatus.applied
    assert len(controller.knowledge) == 1

@pytest.mark.asyncio
async def test_compound_brain_combines_specialist_lanes():
    result = await CompoundBrain().solve('Design a safe research workflow')
    assert result.verified is True
    assert len(result.lanes) == 4
    assert 'Objective:' in result.answer
