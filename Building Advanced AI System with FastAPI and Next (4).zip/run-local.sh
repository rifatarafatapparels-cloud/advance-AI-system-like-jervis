#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [ ! -x backend/.venv/bin/uvicorn ] || [ ! -d frontend/node_modules ]; then
  echo "RHB AI is not set up yet. Running setup-local.sh..."
  ./setup-local.sh
fi

cleanup() {
  trap - INT TERM EXIT
  [ -n "${BACKEND_PID:-}" ] && kill "$BACKEND_PID" 2>/dev/null || true
  [ -n "${FRONTEND_PID:-}" ] && kill "$FRONTEND_PID" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

backend/.venv/bin/uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000 > /tmp/rhb-ai-backend.log 2>&1 &
BACKEND_PID=$!
(cd frontend && npm run start -- -H 127.0.0.1 -p 3000 > /tmp/rhb-ai-frontend.log 2>&1) &
FRONTEND_PID=$!

sleep 3
URL="http://127.0.0.1:3000"
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1 || true; elif command -v open >/dev/null 2>&1; then open "$URL" || true; fi
printf '\nRHB AI is running locally at %s\nAPI docs: http://127.0.0.1:8000/docs\nPress Ctrl+C to stop.\n\n' "$URL"
wait "$FRONTEND_PID"
