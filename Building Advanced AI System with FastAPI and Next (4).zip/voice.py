"""Voice extension contracts.

The browser can use Web Speech APIs immediately through the UI. Server-side
providers can be added later for private transcription, synthesis, and wake
word handling without changing task orchestration.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterator

@dataclass
class VoiceConfig:
    language: str = "en-US"
    wake_word: str = "RHB"
    enabled: bool = True
    require_confirmation_for_external_actions: bool = True

class SpeechProvider(ABC):
    @abstractmethod
    async def transcribe(self, audio: bytes, config: VoiceConfig) -> str: ...
    @abstractmethod
    async def synthesize(self, text: str, config: VoiceConfig) -> bytes: ...

class BrowserSpeechProvider(SpeechProvider):
    async def transcribe(self, audio: bytes, config: VoiceConfig) -> str:
        raise NotImplementedError("Use browser Web Speech recognition or configure a server STT provider")
    async def synthesize(self, text: str, config: VoiceConfig) -> bytes:
        raise NotImplementedError("Use browser speechSynthesis or configure a server TTS provider")

class VoiceGateway:
    def __init__(self, provider: SpeechProvider | None = None, config: VoiceConfig | None = None) -> None:
        self.provider = provider or BrowserSpeechProvider()
        self.config = config or VoiceConfig()

    async def transcribe(self, audio: bytes) -> str:
        return await self.provider.transcribe(audio, self.config)

    async def synthesize(self, text: str) -> bytes:
        return await self.provider.synthesize(text, self.config)

voice_gateway = VoiceGateway()
